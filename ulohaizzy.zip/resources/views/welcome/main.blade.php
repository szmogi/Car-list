
  <main  id="app">
           
       
       
            <welcome-cars
            :data-cars="{{$dataCars}}">

              
            </welcome-cars>





    </main>