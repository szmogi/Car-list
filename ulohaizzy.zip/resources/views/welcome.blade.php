
@extends ('welcome.footer')
@extends ('welcome.main')
@extends ('welcome.header')



